import java.util.ArrayList;

public class GUI_Gebruik
{
    public GUI_Gebruik() 
    {
        IO.init();
        GUI_Matrix_Helper.clrDisplay();
        Windcompass.DrawWindcompass(45, 55);
    }
}
